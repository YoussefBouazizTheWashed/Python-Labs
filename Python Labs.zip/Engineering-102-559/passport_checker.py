# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Niko Hu
# Names: Hollis Harlan
# Names: Youssef Bouaziz
# Names: Steven Talbott
# Section: 559
# Assignment: Lab 11: Passport Checker
# Date: 29 October 2025

# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Niko Hu
# Names: Hollis Harlan
# Names: Youssef Bouaziz
# Names: Steven Talbott
# Section: 559
# Assignment: Lab 11: Passport Checker
# Date: 29 October 2025
'''
This program reads passports from the user-given file name and generates a file named "valid_passports.txt"
that contains all valid passports containing all 7 required fields, then prints the number of valid passports found.
'''

# Parallel passport lists
passports = []              # List containing dictionaries of fields and their values
string_passports = []       # List containing passports as strings; formatted same as the input file

input_filename = input("Enter the name of the file: ")

# Populate passports and string_passports from the input file
with open(input_filename, "r") as input_file:
    list_passports = list(input_file)
    i = 0

    while i < len(list_passports):
        string_passport = ""
        passport = {}

        # Runs from start line to end line of a passport
        while i < len(list_passports) and list_passports[i] != "\n":

            # Add line to the formatted passport
            string_passport += list_passports[i]

            # Split the fields on the line into key:value pairs and add them to the passport dictionary
            for field in (list_passports[i].strip().split(" ")):
                field = field.split(":")
                passport[field[0]] = field[1]
            i+=1

        # Add the passport dictionary and formatted passport to their respective lists
        passports.append(passport)
        string_passports.append(string_passport + "\n")
        i+=1

# Writing valid passports to output file
with open("valid_passports.txt", "w") as output_file:
    valid_count = 0
    for i in range(len(passports)):
        fields = passports[i].keys()

        # Check for valid conditions and write if valid
        if len(fields) == 8 or (len(fields) == 7 and "byr" not in fields):
            output_file.write(string_passports[i])
            valid_count += 1

# Display results
print(f"There are {valid_count} valid passports")
