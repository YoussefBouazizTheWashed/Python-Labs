# By submitting this assignment, I agree to the following:
#   "Aggies do not lie, cheat, or steal, or tolerate those who do."
#   "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Youssef Bouaziz
# Section:      559
# Assignment:   Lab Topic 8 Team
# Date:         October 14 2025

import math
# n = [3,2,5,6,45,31,65,7]

def parta(numbers):
    '''Takes a list and turns the string into float values and creates '''
   
    real_list = []

    sub_list = []

    #Creates a list of floats from the string list
    for value in numbers:
        sub_list.append(float(value))
    func_list = sorted(sub_list)
    real_list.append(func_list[0])

    #Checks for whether the list was had an odd or even length 
    if len(func_list)%2==0: #If even we grab the middle two and take the average
        real_list.append((func_list[len(func_list)//2]+(func_list[(len(func_list)//2)-1])))
    elif len(func_list)%2!=0:
           real_list.append(func_list[len(func_list)//2])
    real_list.append(func_list[len(func_list)-1])
    return real_list
parta(n)
        
#--------------------------------------------------------------------

# time = [12, 45, 100, 130, 250]
# distance = [0, 17, 84, 100, 701]

def partb(list_t,list_d):
    '''Grabs distance and time and returns veolcity for the parellel values
    of their respective lists with the last value in both lists being cutoff'''
    velocity = []
    for value in range(len(list_t)):
        velocity.append(list_d[value]/list_t[value])
    return velocity[0:len(velocity)-1] 
        
# print(partb(time, distance))

#--------------------------------------------------------------------

#n=[1000, 1029]

def partc(list_of_num):
    '''If two of the numbers in the list add up to 2029 then we return the product of those two numbers'''
    product = False
    #Goes through the list for each number to find all possible value 
    for constant in (list_of_num):
        for var in (list_of_num):
            #Checks if it is currently on itelf through the list
            if list_of_num.index(var) == list_of_num.index(constant):
                continue

            elif constant + var == 2029:
                product = constant * var
    return product

#partc(n)


#n = [2,4,6,8,10] #Take numbers next to each other
#and determine if they can create the given integer
#Ex. 2,4,6,8 (4 and 6 equal 10[given integer] 
#so return 4 and 6 in a list)

def partd(pos_int):
    
    '''takes a positive integer and grabs all positive even conseceutive values next to each other that add up to that positive integer'''
    even_int = []
    value = 0
    true_list = []
    #takes all positive even integers for 2<=x<=pos_int
    for even in range(2,pos_int,2):
       even_int.append(even)
    if pos_int%2!=0:
        true_list = False
    elif pos_int%2==0:
        j=0

        #because we know pos_int is divisble by 2 and we made a list that contains all the even numbers between 0 and pos_int(ex. 10)
        # we just check if j our counter value is less than the value of pos_int/2(for 10 --> [2,4,6,8])
        while j < len(even_int)-1:
            num_list = []
            print(j)

            value = 0 #reset value to zero when trying to create a new iteration 
            for i in range(len(even_int)-j):

                if value < pos_int: #adds to value and appends to num_list if less than the given integer(pos_int)
                        index = i+j
                        value += even_int[index] #j represents the start of the value in the list even_int
                        num_list.append(even_int[index])
                        
                        if value > pos_int:
                            #Checks if value is greater than pos_int and adds 1 to j then
                            #breaks out of the inner loop skipping to another iteration of the while loop
                            j+=1
                            break
                    


                elif value == pos_int:
                    #Append the total values that add to pos_int when value is pos_int
                    true_list.append(num_list)
                    j+=1
                    break

                
    print(true_list)

    return true_list

# partd(300)

#------------------------------------------------

def parte(radius_sphere,radius_hole):
    '''Takes the volume of a bead throug the radius of the spehere and the radius of the beads hole'''
    triangle_side = radius_sphere**2-radius_hole**2
    hemisphere_radius = radius_sphere-triangle_side

    sphereVol = math.pi*(4/3)*radius_sphere**3
    hemisphere_vol = math.pi*(2/3)*hemisphere_radius**3
    cylinder_vol = math.pi*(radius_sphere-2*hemisphere_radius)*radius_hole**2

    tot_vol = sphereVol - cylinder_vol - 2*hemisphere_vol

    return tot_vol

# print(parte(10,2))



#------------------------------------------------------------------------


def partf(character, name, company, email):
    '''Creates a business card that has a border always a little longer than the longest paremeter'''

    finale = ''
    sub = 0

    #Finding longest string to create border size
    partf_list = [character, name, company, email]

    for j in partf_list:
        if len(j) > sub:
            sub = len(j)
    
    for x in range(5):
        finale+='\n' #New line for each parameter

        #Length of the border printed out sequentially
        for i in range(1,sub+6+1):
            if x == 0: #Fill top border with characters paremeter
                finale += character

            if x==1: #Enter charcter if first or last iteration of border
                if i==1 or i==(sub+6):
                    finale+=character
                #the distance subtracted the paremeters length is the distance at which we print out that paremeter
                #since we are using integer division we add an extra spacce too.
                elif ((sub+6)-len(name))//2 == i:
                    finale+=' '
                    finale += name
                #Checks when the iteration 'i' has passed the langth of the paremeter input and then starts to add spaces and a final character to finish the border
                elif i > len(name)+((sub+6)-len(name))//2 or i < ((sub+6)-len(name))//2:
                    finale += ' '
            #Repeat previous procedure with all lines with their respective paremeters, unless we are on the final line then the conditional of x==0 is applied instead 

            elif x==2:
                if i==1 or i==((sub+6)):
                    finale+=character

                elif ((sub+6)-len(company))//2 == i:
                    finale+=' '
                    finale += company

                elif i > len(company)+((sub+6)-len(company))//2 or i < ((sub+6)-len(company))//2:
                    finale += ' '
                     


            elif x==3:
                if i==1 or i==(sub+6):
                    finale+=character
                elif ((sub+6)-len(email))//2 == i:
                    finale+=' '
                    finale += email
                elif i > len(email)+((sub+6)-len(email))//2 or i < ((sub+6)-len(email))//2:
                    finale += ' '


            elif x==4:
                finale+=character

    return finale
        
            
# print(partf('x', 'Hungry', 'tamu.edu.johan', 'unemployed'))


#-------------------------------------------------------------------------------

def partg(x_value, tolerance):
    '''Gives a summation value given using the paremeters as the x value and the tolerance for ln((1+x)/(1-x))'''
    summation = 0
    sum_sub = 0

    n_value = 1

    while True: #Conditional unneeded because we break when sum_sub is less then toleracne
        sum_sub = (2/((2*n_value)-1))*x_value**((2*n_value)-1)
        #Checks if the abs value of sum_sub is greater than tolerance
        
        if abs(sum_sub)>tolerance:
            summation+=sum_sub
            n_value+=1
        #stops running while loop if tolerance has been exceeded
        else:
            break
    return summation

# print(partg(.5,.00006))

#--------------------------------------------------------------------------------