# By submitting this assignment, I agree to the following:
#   "Aggies do not lie, cheat, or steal, or tolerate those who do."
#   "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Youssef Bouaziz
# Section:      559
# Assignment:   Lab Topic 8 Team
# Date:         October 14 2025

import math

numbers = '' 
numbers = input('Enter a list of numbers')
numbers = numbers.split()

number = [1, 2, 3, 4, 5, 6, 7]

def parta(numbers):
    '''Takes a list and turns the string into integer values'''


    sub_list = []
    for value in numbers:
        sub_list.append(float(value))
    func_list = sorted(sub_list)
    print(func_list[0])

    if len(func_list)%2==0:
        print((func_list[len(func_list)//2]+(func_list[(len(func_list)//2)-1])))
    elif len(func_list)%2!=0:
       print(func_list[len(func_list)//2])
    print(func_list[len(func_list)-1])

        
parta(numbers)
#--------------------------------------------------------------------

time = [12, 45, 100, 130, 250]
distance = [0, 17, 84, 100, 701]

def partb(list_t,list_d):
    '''Grabs distance and time and returns veolcity for the parellel values
    of their respective lists'''
    velocity = []
    for value in range(len(list_t)):
        velocity.append(list_d[value]/list_t[value])
    return velocity[0:len(velocity)-1] 
        
print(partb(time, distance))

#--------------------------------------------------------------------

n=[1000, 1029]

def partc(list_of_num):
    i = False
    global product
    product = 1
    for constant in (list_of_num):
        for var in (list_of_num):
            if list_of_num.index(var) == list_of_num.index(constant):
                continue
            elif constant + var == 2029:
                product = constant * var
    return product

partc(n)


n = [2,4,6,8,10] #Take numbers next to each other
#and determine if they can create the given integer
#Ex. 2,4,6,8 (4 and 6 equal 10[given integer] 
#so return 4 and 6 in a list)

def partd(pos_int):
    global even_int 
    even_int = []
    value = 0
    global true_list
    true_list = []
    for even in range(2,pos_int,2):
       even_int.append(even)
    if pos_int%2!=0:
        return False
    elif pos_int%2==0:
        j=0

        #because we know pos_int is divisble by 2 and we made a list that contains all the even numbers between 0 and pos_int(ex. 10)
        # we just check if j our counter value is less than the value of pos_int/2(for 10 --> [2,4,6,8])
        while j < pos_int/2:
            num_list = []

            value = 0 #reset value to zero when trying to create a new iteration 
            for i in range(len(even_int)-j):

                if value < pos_int: #adds to value and appends to num_list if less than the given integer(pos_int)
                        index = i+j
                        value += even_int[index] #j represents the start of the value in the list even_int
                        num_list.append(even_int[index])
                    


                elif value == pos_int:
                    #Append the total values that add to pos_int when value is pos_int
                    true_list.append(num_list)
                    num_list = []
                    j+=1
                    break

                #Checks if value is greater than pos_int and adds 1 to j then breaks out of the inner loop skipping to another iteration of the while loop
                elif value > pos_int:
                    num_list = []
                    j+=1
                    break

    return true_list
n = 10


                









    
    
                
    


print(partc(n))

        







































































































































































































































































































































    


