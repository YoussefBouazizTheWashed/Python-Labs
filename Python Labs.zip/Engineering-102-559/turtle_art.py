# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Youssef Bouaziz
# Section: 559
# Assignment: Lab 12
# Date: 12 November 2025
import math as mt
import turtle as turt

#Take turn angel return least amount of 
#iteration values needed to get back to the start
def spiralmaker(num):
   #Generate string based on number of turns needed in a spiral shape
   compare = 0
   seq = ''
   for i in range(num):
   
      counter = 0
      seq+='1'
      while counter < compare:
         seq+='0'
         counter+=1
      compare+=1
   return seq


def parta(angle):
   #Calculate number of iterations to complete a shape based on angle
   count = 1
   sum = angle
   while (sum%360) != 0:
      sum+=angle
      count+=1
   for i in range(count):
      turt.left(angle)
      turt.forward(300)
   return count

binary = ['0','1']

def partb(string):
   #Use string to draw based on 30 degree left for 0 and 114 degree right for 1
   compare_sum = 0
   for i in list(string):
      if i == '0':
         compare_sum+=30
      elif i == '1':
         compare_sum-=114
   sum = compare_sum
   iteration = 1
   while (sum%360) !=0:
      sum+=compare_sum
      iteration+=1
   # for i in range(iteration):
   #    for i in string:
   #       if i =='0':
   #          turt.left(30)
   #          turt.forward(40)
   #       elif i == '1':
   #          turt.right(114)
   #          turt.forward(40)
      
   return iteration

print(partb('01001'),partb('01001011'),partb('010010110000101'))

def partc(string, z_angle, o_angle):
   #Calculate use angles to draw a spiral based on string
   for i in string:
      if i =='0':
         turt.left(z_angle)
         turt.forward(5)
      elif i == '1':
         turt.left(o_angle)
         turt.forward(5)
   return string


turt.dot(10, 'red')



# turt.done()

compare = 1

#Defining seq1 and two for the partc in main function
seq1 = spiralmaker(20)
seq2 = spiralmaker(50)
print(seq1)
print(seq2)



def main():
   #Set turtle speed to max and run each part with a reset
   #  in between with inputs to view each part
   turt.speed(0)
   parta(160)
   input()
   turt.reset()
   turt.speed(0)
   turt.dot(10, 'red')
   parta(141)
   input()
   turt.reset()
   turt.speed(0)
   turt.dot(10, 'red')
   partb('01001')
   input()
   turt.reset()
   turt.speed(0)
   turt.dot(10, 'red')
   partb('01001011')
   input()
   turt.reset()
   turt.speed(0)
   turt.dot(10, 'red')
   partc(seq1, 0, 90)
   input()
   turt.reset()
   turt.speed(0)
   turt.dot(10, 'red')
   partc(seq1, 0, 30)
   input()
   turt.reset()
   turt.speed(0)
   turt.dot(10, 'red')
   partc(seq2, 0, 150)
   input()
   turt.reset()
   turt.speed(0)
   turt.dot(10, 'red')
   partc(seq2, 5, 108)
   input()
   turt.reset()
   turt.speed(0)
   turt.dot(10, 'red')
   turt.update()
   turt.done()
main()


   



   

