# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Youssef Bouaziz
# Section: 559
# Assignment: Lab 12
# Date: 8 November 2025

'''Using the WeatherDataCLL.csv We create four graphs, the first one is a graph
 that shows the values for the pressure and wetbulb over the course of ten years every day using independent y axes.
 The second is a histogram of all windspeeds everyday over the past ten years,
 the third is a scatterplot having humidity percentage values with respect to dewpoint temperature values.
 The final graph shares both the x and y axis for four diffrent data inputs for max temp in a month over ten years, min tempi in a month over ten years,
   mean average temp in a month over the course of ten years, and mean of total precipitation in a month over the course of ten years.'''

import matplotlib.pyplot as plt
import numpy as np

#Used to weed out blank or incorrect data
global character
character = [',', '/', '']

#Dictionary created for later use for the last problem
#  where four sets of data need to be divided by month
month = {}
for i in range(1,13):
    month[str(i)] = [[],[],[],[]]

with open('WeatherDataCLL.csv', 'r') as weather_data:
    wind_speed = []
    wet_bulb = []
    pressure = []
    day = []
    day2 = []
    day3 = []
    #I was taught how to use this by my teammates 
    #(literally a for loop with a built in iteration counter 
    # nothing else special to it)
    for data in weather_data:
        title_list = data.split(',')
        break

    #Create data dictionary with the titles of the weater data in the weathdatacll.csv as keys
    data_dict = {}
    for i in title_list:
        data_dict[i] = []
        
    #Data appended to list within dictionary that is seperated by the titles(read preious comment)
    for iterate,data in enumerate(weather_data):
        temp_list = data.split(',')
        if temp_list[3] not in character: 
            data_dict[title_list[3]].append(float(temp_list[3]))
            day.append(iterate)

        if temp_list[2] not in character:
            data_dict[title_list[2]].append(float(temp_list[2]))
            day2.append(iterate)
        
        if temp_list[4] not in character:
            data_dict[title_list[4]].append(float(temp_list[4]))
            day3.append(iterate)


        if temp_list[1] not in character:
            data_dict[title_list[1]].append(float(temp_list[1]))

        if temp_list[6] not in character:
            data_dict[title_list[6]].append(float(temp_list[6]))

            if len(data_dict[title_list[1]]) > len(data_dict[title_list[6]]):
                diff = len(data_dict[title_list[1]]) - len(data_dict[title_list[6]])
                for i in range(diff):
                    data_dict[title_list[1]] = data_dict[title_list[1][:-1]]
            elif len(data_dict[title_list[1]]) < len(data_dict[title_list[6]]):

                diff = len(data_dict[title_list[6]]) - len(data_dict[title_list[1]])
                for i in range(diff):
                    data_dict[title_list[6]] = data_dict[title_list[6]][:-1]

            #Split the date using split function
            placeholder = temp_list[0].split('/')
            #Grabbing only the month
            check = placeholder[0]

            p = temp_list[-5]
            at = temp_list[-3]
            ht = temp_list[-2]
            lt = temp_list [-1]
            #Input data into easily retrievable lists that have keys correspondent to their month
            if p not in character:
                month[check][0].append((temp_list[-5]))
            if at not in character:
                month[check][1].append((temp_list[-3]))
            if ht not in character:
                month[check][2].append((temp_list[-2]))
            #Removing the \n at the end
            if lt not in character:
                month[check][3].append((temp_list[-1][:-1]))
        #Adding the mean avg temp to a new lst using the previous list with all the stored data
    mean = {'precip':[], 'avgt':[], 'maxt':[], 'mint':[]}

    #iterate through month and add respective needed data types for the last graph
    for time in month:
        for x in month[time]:
            #Grab total precip for single month over ten years and divide it by 10
            if month[time][0] == x:
                sum = 0
                iteration = 0
                for e in (x):
                    sum+=float(e)
                mean['precip'].append((sum/10))

            # Grab all temps in a single month over ten years 
            # and get the mean for that month's avg temp
            if month[time][1] == x:
                sum = 0
                iteration = 0
                for e in (x):
                    sum+=float(e)
                    iteration +=1
                mean['avgt'].append((sum/iteration))
            
            #Finding the max highest temp in a month
            if month[time][2] == x:
                max = 0
                for e in (x):
                    
                    if float(e)> max:
                        max = float(e)
                mean['maxt'].append(max)

            #Finding the lowest low temp in a month
            if month[time][3] == x:
                min = 100000
                for e in (x):
                    if e == '':
                        continue
                    if float(e)< min:
                        min = float(e)
                mean['mint'].append(min)
print(mean['precip'])
    
#Create a new figure
fig, graph = plt.subplots()
wetbulb_line, = graph.plot(day,data_dict[title_list[3]], color = 'red')
graph.set_ylabel('Average Wet Bulb Temperature, F')
graph.set_xlabel('date')
#Set data points of different graphs to 
# share same x axis but have different y axis
graph2 = graph.twinx()
Pressure_line, = graph2.plot(day2,data_dict[title_list[2]], color = 'blue')
graph2.legend([wetbulb_line,Pressure_line],['Avg Wetbulb Temperature','Avg Pressure'], loc = 'lower left', )
fig.suptitle('Average Wet Bulb Temperature and Average Pressure')
graph2.set_ylabel('Average Pressure, in Hg')

#Create new figure
fig2, graph3 = plt.subplots()
#Create histogram to find windspeed's most common values
graph3.hist(data_dict[title_list[4]], bins=np.linspace(0,20,31), color = 'green', label = 'Average windspeed', linewidth = 1, edgecolor = 'k')
fig2.suptitle('Histogram of Average Wind Speed')
graph3.set_ylabel('Number of days')
graph3.set_xlabel('Average Wind Speed, mph')

#Create new figure 
fig3, graph4 = plt.subplots()
#Create scatter plot using average humidity percent with respect to average dew point temp
graph4.scatter(title_list[1], title_list[6], s=8, color = 'green',data = data_dict)
graph4.set_ylabel('Average Humidity (%)')
graph4.set_xlabel('Average Dew Point (F)')
fig3.suptitle('Average Humididty vs Average Dew Point')


#Create new figure
fig4, graphs = plt.subplots()

#Create x label
graphs.set_xlabel('Month')
# X axis list
x = np.linspace(1,12,12)

#Plot all of the given data from the mean dictionary into the graph as needed
maxt = graphs.plot(x,'maxt',data = mean)

mint = graphs.plot(x,'mint',data = mean)
precip = graphs.plot(x, 'precip', color = '#008080',data = mean)
avgt = graphs.bar(x,'avgt',color = '#9ACD32',data = mean) 
graphs.legend(['High T', 'Low T', 'Precip'], loc = 'upper left')
#Create y label
graphs.set_ylabel('Average Temperature, F\nMonthly Percipitation, in')
#Setting ticks shown on x axis to 12 through alreday existing list
graphs.set_xticks(x)
plt.show()




