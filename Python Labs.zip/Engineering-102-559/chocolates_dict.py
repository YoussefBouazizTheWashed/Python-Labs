# chocolate_boxes.py
# ENGR 102 - Lab Topic 10 (Team)
# Activity 1: Make 25 boxes of chocolate truffles
# Each box must have 4 truffles and meet all the constraints.

def make_boxes(chocolates):
    """
    chocolates: dict {id: [type, shape, filling, topping]}
    returns: list of 25 boxes (each is a list of 4 unique truffle IDs)
    """

    # --- Rule checker ---
    def is_valid_add(box, truffle_id):
        """Check if adding truffle_id to current box keeps it valid."""
        items = [chocolates[i] for i in (box + [truffle_id])]

        types = [x[0] for x in items]
        shapes = [x[1] for x in items]
        fillings = [x[2] for x in items]
        toppings = [x[3] for x in items]

        # 1️⃣ No duplicates
        if len({tuple(x) for x in items}) < len(items):
            return False

        # 2️⃣ Caramel and vanilla cannot coexist
        if "caramel" in fillings and "vanilla" in fillings:
            return False

        # 3️⃣ Nuts and sprinkles cannot coexist
        if "nuts" in toppings and "sprinkles" in toppings:
            return False

        # 4️⃣ Square and rectangle cannot coexist
        if "square" in shapes and "rectangle" in shapes:
            return False

        # 5️⃣ Dark chocolate rule
        dark_count = types.count("dark")
        if dark_count > 3:  # too many darks
            return False
        if len(items) == 4 and dark_count not in (0, 2, 3):
            return False

        return True

    # --- Backtracking search ---
    truffle_ids = list(chocolates.keys())
    boxes = [[] for _ in range(25)]
    used = set()

    def backtrack(index=0):
        """Recursively assign truffles to boxes."""
        if index == len(truffle_ids):
            return True  # all truffles placed successfully

        tid = truffle_ids[index]
        for b in range(25):
            box = boxes[b]
            if len(box) < 4 and is_valid_add(box, tid):
                box.append(tid)
                used.add(tid)

                if backtrack(index + 1):
                    return True  # success!

                # backtrack if it didn’t work
                box.remove(tid)
                used.remove(tid)

        return False  # no valid placement found → backtrack

    solved = backtrack()

    if not solved:
        print("⚠️ Warning: could not satisfy all constraints. Some boxes may be incomplete.")

    return boxes
