import matplotlib.pyplot as plt
import numpy as np


# x = np.linspace(-2,2,80)
# line1 = plt.plot(x, (1/8)*(x**2), 'r',linewidth = 2)
# line2 = plt.plot(x, (1/24)*(x**2), 'b', linewidth = 6)
# plt.legend(['f=2','f=6'])

# plt.title('Parabola plots with varying focal lengths')
# plt.axis((-2,2,0,.5)) # This determines the fuckass width and height of the graph
# plt.show()

#OMG IM SO HAPPY I DID IT I DID IT I DID IT!!!

# x = np.linspace(-4,4,25)
# y = 2*x**3 + 3*x**2 -11*x - 6
# fucker = plt.plot(x,y, color = '#FFED29', marker = '*', linewidth = 0, markersize = 15, markeredgecolor = 'black')
# plt.xlabel('x values')
# plt.ylabel('y values')
# plt.show()

 
x = np.linspace(-2*np.pi, 2*np.pi, 50)


fig, (graph1, graph2) = plt.subplots(2,1)
fig.suptitle('Graph of Sine and Cosine')


graph1.plot(x, np.cos(x),'r')
graph2.plot(x,np.sin(x), 'b')

graph1.tick_params(labelbottom = False)
graph1.grid(True)
graph2.grid(True)

graph1.set_ylabel('y=cos(x)')
graph2.set_ylabel('x=sin(x)')
graph2.set_xlabel('x')

graph1.legend(['Cos'])
graph2.legend(['Sin'])




plt.show()