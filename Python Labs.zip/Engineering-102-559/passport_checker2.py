# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Niko Hu
# Names: Hollis Harlan
# Names: Youssef Bouaziz
# Names: Steven Talbott
# Section: 559
# Assignment: Lab 11: Passport Checker
# Date: 29 October 2025
'''
This program reads passports from the user-given file name and generates a file named "valid_passports.txt"
that contains all valid passports containing all 7 required fields, then prints the number of valid passports found.
'''

# Parallel passport lists
passports = []              # List containing dictionaries of fields and their values
string_passports = []       # List containing passports as strings; formatted same as the input file

input_filename = input("Enter the name of the file: ")

# Populate passports and string_passports from the input file
with open(input_filename, "r") as input_file:
    list_passports = list(input_file)

    i = 0

    while i < len(list_passports):
        string_passport = ""
        passport = {}

        # Runs from start line to end line of a passport
        while i < len(list_passports) and list_passports[i] != "\n":

            # Add line to the formatted passport
            string_passport += list_passports[i]

            # Split the fields on the line into key:value pairs and add them to the passport dictionary
            for field in (list_passports[i].strip().split(" ")):
                field = field.split(":")
                passport[field[0]] = field[1]
            i+=1

        # Add the passport dictionary and formatted passport to their respective lists
        passports.append(passport)
        string_passports.append(string_passport + "\n")
        i+=1
# Writing valid passports to output file
# with open("valid_passports.txt", "w") as output_file:
#     valid_count = 0
#     for i in range(len(passports)):
#         fields = passports[i].keys()

#         # Check for valid conditions and write if valid
#         if len(fields) == 8 or (len(fields) == 7 and "byr" not in fields):
#             output_file.write(string_passports[i])
#             valid_count += 1
#     print(output_file)

# #Display results
# print(f"There are {valid_count} valid passports")



# with open('valid_passports.txt', 'r') as PMO_file:
#     random_dict = {}
#     ungabunga = list(PMO_file)
#     for oogly in ungabunga:
#         boogly = oogly.split(' ')
#         print(boogly)
#         random_dict = True


# print(passports)

sec_file = open('valid_passports2.txt', 'w')

letter = ['a','b','c','d','e','f']
number = ['1','2','3','4','5','6','7','8','9','0']
eye = ['amb', 'blu', 'brn', 'gry', 'grn', 'hzl', 'oth']
h = 0
for x in passports:
    score = 0
    for i in x:
        #finding valid initial year
        if i == 'iyr' and (2025>=int(x[i])>=2015):
            # print('iyr')
            score+=1
            # print('initial year',score)
        #finding valid expiration year
        elif i == 'eyr' and (2035>=int(x[i])>=2025):
            # print('eyr')
            score+=1
            # print('expiration year',score)
        #finding valid height
        elif i == 'hgt':
            if x[i][-2:] == 'in' and 76>=int(x[i][:-2])>=59:
                # print('hgt')
                score+=1
                # print('height', score)
            elif x[i][-2:] == 'cm' and 193>=int(x[i][:-2])>=150:
                # print('hgt')
                score+=1
                # print('height', score)
        #Finding valid hair color
        elif i == 'hcl':
            # print('hcl')
            counter = 1
            for z in x[i]:
                if x[i][0] == '#': 
                    if z in letter or z in number:
                        counter+=1
            if counter == 7:
                score+=1
                # print('hair color', score)
        #Eye color
        elif i == 'ecl':
            # print('ecl')
            if x[i] in eye:
                score+=1
                # print('eye color', score)
        #Passport ID
        if i == 'pid':
            # print('pid')
            count = 0
            if len(x[i]) == 9:   
                for f in x[i]:
                    if f in number:
                        count+=1
            if count == 9:
                score+=1
                # print('passport id',score)
        #Country ID
        if i == 'cid':
            # print('cid')
            counting = 0
            if x[i] != '':
                if x[i][0] == '0':
                # print('before cut', x[i])
            
                    x[i] = x[i][1:]
                # print('after cut',x[i])
                if len(x[i]) == 3:
                    for r in x[i]:
                        if r in number:
                            counting+=1
                    if counting == 3:
                        score+=1
                    # print('country id',score)
    #Write passports to new file
    if score == 7:
        sec_file.write(string_passports[passports.index(x)])
        h+=1
print(f'There are {h} valid passports')

sec_file.close()






        
        




                
        

        
