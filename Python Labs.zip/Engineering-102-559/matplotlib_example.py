# As a team, we have gone through all required sections of the
# tutorial, and each team member understands the material

# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Niko Hu
# Names: Hollis Harlan
# Names: Youssef Bouaziz
# Names: Steven Talbott
# Section: 559
# Assignment: Lab 12: matplotlib_example
# Date: 29 October 2025


'''Creates three graphs one with two quadratic lines of varying linewidth,
the second with a cubic equation that is shown with golden stars,
and the final is two equations that range from -2pi to 2pi for both cos and sin
but on seperate graphs stacked onto each other'''

import matplotlib.pyplot as plt
import numpy as np



x = np.linspace(-2,2,80)
line1 = plt.plot(x, (1/8)*(x**2), 'r',linewidth = 2)
line2 = plt.plot(x, (1/24)*(x**2), 'b', linewidth = 6)
plt.legend(['f=2','f=6'])

plt.title('Parabola plots with varying focal lengths')
plt.axis((-2,2,0,.5)) # This determines the width and height of the graph
plt.show()



x = np.linspace(-4,4,25) #Creates a list that starts at -4 and ends at 4 with 25 segements inbetween that are equal in length
y = 2*x**3 + 3*x**2 -11*x - 6
Stars = plt.plot(x,y, color = '#FFED29', marker = '*', linewidth = 0, markersize = 15, markeredgecolor = 'black')
plt.xlabel('x values')
plt.ylabel('y values')
plt.show()

 
x = np.linspace(-2*np.pi, 2*np.pi, 50) #Same thing as before but -2pi <= x <= 2pi

#Defining two variables as a tuple which are each equal to their respective graph
fig, (graph1, graph2) = plt.subplots(2,1) #Putting the second option before the first one lets us stakc vertically
fig.suptitle('Graph of Sine and Cosine')#Title of the entire figure


graph1.plot(x, np.cos(x),'r') #using numpy's function for cos
graph2.plot(x,np.sin(x), 'b') #Same thing here

graph1.tick_params(labelbottom = False) #This removes the x axis from the stacked graph
graph1.grid(True) #Making the grids for both graphs visible
graph2.grid(True)

#Creating labels
graph1.set_ylabel('y=cos(x)')
graph2.set_ylabel('x=sin(x)')
graph2.set_xlabel('x')

#Creating the legend for both cos and sine
graph1.legend(['Cos'])
graph2.legend(['Sin'])




plt.show()

