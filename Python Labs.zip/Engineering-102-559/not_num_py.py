# As a team, we have gone through all required sections of the
# tutorial, and each team member understands the material

# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Niko Hu
# Names: Hollis Harlan
# Names: Youssef Bouaziz
# Names: Steven Talbott
# Section: 559
# Assignment: Lab 11: Passport Checker
# Date: 29 October 2025

import numpy as np

A = np.arange(12).reshape(3,4)
B = np.arange(8).reshape(4,2)
C = np.arange(6).reshape(2,3)
print("A =", A)
print("B =", B)
print("C =", C)



D = A @ B @ C
print("D =", end = ' ')
print(D)

print("D^T =", end = ' ')
print(D.T)
print("")
print('E = ', end = '')
print(np.sqrt(D)/2)


# A = np.array([[1, 1],
#               [0, 1]])
# B = np.array([[2, 0],
#               [3, 4]])
# print(A * B)    # elementwise product
# print(A @ B)     # matrix product
# print(A.dot(B))  # another matrix product