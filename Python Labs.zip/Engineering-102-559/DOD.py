

# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Youssef Bouaziz
#        Carleston Wilkes
#        Riddoc Murray
#        Edgar Remirez
# Section: 559
# Assignment: Lab:Team Project House of Cards
# Date: 7/12/25


import math as m
import matplotlib.pyplot as mp
import turtle as t

def create_DOD():
    '''python program that creates the tower in a simple 2d setting using turtle graphics so that we can visualize the tower we built using cards and pennies. The tower is made up of a series of rectangles that represent the cards and a base and top that holds the pennies. 
    The dimensions of the tower are based on the number of cards and pennies used in the tower.'''
    inch = 12
    t.color('violet')
    #Something to get the window to pop up with a title
    t.penup()
    t.speed(0)
    t.left(90)
    t.pendown()
    t.begin_fill()
    #Creating the main rectangle
    for i in range(2):
        t.forward(37*inch)
        t.left(90)
        t.forward(3*inch)
        t.left(90)
    t.fillcolor('green') #Representing it with a green color


    t.end_fill()
    #Creating the inner lines the represents the multiple cards that make it up
    for i in range(8):
        t.forward(4.625*inch)
        t.left(90)
        t.forward(3*inch)
        t.back(3*inch)
        t.right(90)
    t.back(37*inch)
    t.penup()

    t.begin_fill()
    t.forward(37*inch)
    t.pendown()
    t.left(180)

    #Creating the top that holds the pennies
    for i in range(2):
        t.forward(inch)
        t.right(90)
        t.forward(3*inch)
        t.right(90)
    t.fillcolor('orange')


    t.end_fill()
    t.setheading(0)
    t.right(90)
    t.forward(37*inch)
    t.left(90)
    t.forward(inch)
    t.penup()
    t.pendown()
    t.begin_fill()

    #Creating the base that keeps the tower stable
    for i in range(2):
        t.left(90)

        t.forward(3*inch)
        t.left(90)
        t.forward(5*inch)
    t.back(2.5*inch)
    t.left(90)
    t.fillcolor('orange')




    t.end_fill()
    t.forward(3*inch)


    t.done()
    t.bye()
def estimate():
    '''
    Gathers estimate data previously found and returns the estimated profit
    '''
    # Gather estimates
    est = 0
    cardsE = int(input('How many cards do you plan to use? '))
    tapeE = int(input('How many rolls of tape do you plan to use? '))
    scisE = int(input('How many pairs of scissors do you plan on using? '))
    timeE = int(input('How long do you plan on spending? '))
    heightE = float(input('How tall do you plan on building (in inches down to 1/4th inches)? '))
    strengthE = int(input('How many pennies do you plan on holding? '))
    
    # Calculate estimate
    if timeE < 25:
        est += (25-timeE)*1000
    else:
        est -= (timeE-25)*2000
    if heightE > 36:
        est += (m.floor(heightE)-36)*2000
    if heightE>=36 and strengthE>=10:
        est+=100000
    if strengthE > 10:
        est += (strengthE-10)*500
    est -= ((cardsE*1000)+(tapeE*10000)+(scisE*5000))
    return est

def actual():
    '''
    Gathers data used during the actual event and returns profit with other
    information that is needed for .csv
    ''' 
    # Gather used
    pro = 0
    cards = int(input('How many cards did you use? '))
    tape = int(input('How many rolls of tape did you use? '))
    scis = int(input('How many pair of scissors did you use? '))
    time = int(input('How long did you take? '))
    height = float(input('How tall was your build? (in inches down to 1/4th inches) '))
    strength = int(input('How many pennies did your tower hold? '))
    
    # Calculate profit
    if time < 25:
        pro += (25-time)*1000
    else:
        pro -= (time-25)*2000
    if height>=36 and strength>=10:
        pro+=100000
    if height > 36:
        pro += (m.floor(height)-36)*2000
    if strength > 10:
        pro += (strength-10)*500
    pro -= ((cards*1000)+(tape*10000)+(scis*5000))
    return pro, strength, height

def accuracy(est, pro):
    '''
    Takes the estimated and actual profit and returns the percent error
    '''
    accuracy = 100-((abs(pro - est)/est)*100)
    return accuracy

def files(est, pro, acc, hei, pen):
    '''
    Takes the necessary information (as found in the csv file) and appends it the csv and txt file needed for submission
    '''
    # Write to the .txt file
    file = open('Results.txt', 'w')
    file.write(f'Pennies held: {pen}, Tower height: {hei}in \nEstimated profit: ${est}, Actual profit: ${pro}, Profit Accuracy: {acc:0.0f}%')
    file.close()
    # Write to the .csv file
    file = open('HouseofCardsResults.csv', 'a')
    file.write(f'{int(34)},{pro},{acc:0.0f}%,{m.floor(hei)},{pen}')
    file.close()
    # Gather needed data from .csv
    file = open('HouseofCardsResults.csv', 'r')
    data = file.readlines()
    for i in range(len(data)):
        data[i] = data[i].strip()
        data[i] = data[i].split(',')
    file.close()
    return data
    
def graphs(data):
    '''
    Creates the necessary graphs (height vs weight), (expected vs profit)
    '''
    # Define the lists needed for the height vs weight graph
    hei = []
    for i in range(len(data)):
        try:
            hei.append(int(data[i][3]))
        except:
            try:
                data[i][3] = float(data[i][3])
                hei.append(data[i][3])
            except:
                continue
    wei = []
    for i in range(len(data)):
        try:
            wei.append(int(data[i][4]))
        except:
            continue
    # Define the lists needed for error vs profit graph
    err = []
    for i in range(len(data)):
        data[i][2] = data[i][2].strip('%')
    for i in range(len(data)):
        try:
            err.append(int(data[i][2]))
        except:
            continue
    pro = []
    for i in range(len(data)):
        try:
            pro.append(int(data[i][1]))
        except:
            continue
    # Create HvsW graph
    mp.figure(111)
    mp.scatter(hei[:-1], wei[:-1], c='red', label='Other Teams')
    mp.scatter(hei[-1], wei[-1], c='green', label='Our Team')
    mp.ylabel('Weight (pennies)')
    mp.xlabel('Height (in)')
    mp.title('Height vs Weight')
    mp.legend()
    # Create PvsPE graph
    mp.figure(211)
    mp.scatter(pro[:-1], err[:-1], c='red', label='Other Teams')
    mp.scatter(pro[-1], err[-1], c='green', label='Our Team')
    mp.xlabel('Profit ($)')
    mp.ylabel('Profit Accuracy (%)')
    mp.title('Profit vs Profit Accuracy')
    mp.legend()
    mp.show()

#Run all necessary functions
estimate = estimate()
profit, pennies, height = actual()
error = accuracy(estimate, profit)
data = files(estimate, profit, error, height, pennies)
graphs(data)
print(f'Pennies held: {pennies}, Tower height: {height}in Estimated profit: ${estimate}, Actual profit: ${profit}, Profit Accuracy: {error:0.0f}%')
create_DOD()
