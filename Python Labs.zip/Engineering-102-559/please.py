# By submitting this assignment, I agree to the following:
#   "Aggies do not lie, cheat, or steal, or tolerate those who do."
#   "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Youssef Bouaziz
# Section:      559
# Assignment:   Lab Topic 11 Team
# Date:         October 30 2025

        
#Opening file to find the data needed
with open('WeatherDataCLL.csv', 'r+') as weather_report:
    descriptors = {}
    temp_list = []

    min_temp = 0
    max_temp = 0

    #Put every day for the past to years in a list
    for report in weather_report:
        temp_list.append(report.split(','))

    for report in temp_list:
        print(temp_list)
    print(f'10-year maximum temperature: {max_temp} F')
    print(f'10-year minimum temperature: {min_temp} F')
