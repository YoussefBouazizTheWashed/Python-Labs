# By submitting this assignment, I agree to the following:
#   "Aggies do not lie, cheat, or steal, or tolerate those who do."
#   "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Youssef Bouaziz
# Section:      559
# Assignment:   Lab Topic 11 Team
# Date:         October 30 2025

def month_checker(user_month):
    month = {'jan':1, 'feb':2, 'mar':3, 'apr':4, 'may':5, 'jun':6,
            'jul':7, 'aug':8, 'sep':9, 'oct':10, 'nov':11, 'dec':12}
    for i in month:
        if user_month[:3].lower() == i:
            return month[i]

def list_of_lists(LL, month, year):

    user_year = year
    month_num = month_checker(month)
    range_list = []
    temp_list = []

    for date in LL:
        #Splitting the month day and year
        temp_list = date[0].split('/')
        #chopping off the day
        temp_list = temp_list[:1] + temp_list[2:3]
        #check if month and year are equal to each other
        
        if int(temp_list[0]) == month_num and temp_list[1] == user_year:
            range_list.append(date)
    return range_list



def mean_calc(range_list):
    temp_list = []
    for i in range(1,8):
        temp_value = 0
        counter = 0
        if i == 5:
            no_rain = 0
            for value in range_list:
                if value[i] == '0':
                    no_rain+=1
                else:
                    counter+=1
            temp_list.append((counter/(counter+no_rain))*100)
        
        else:
            for value in range_list:
                if value[i] != '':
                    counter+=1
                    temp_value+=float(value[i])
            temp_list.append(temp_value/counter)

    return temp_list


    
#Opening file to find the data needed
with open('WeatherDataCLL.csv', 'r') as weather_report:
    title_list = []
    temp_list = []

    min_temp = 10000
    max_temp = 0

    # creating list with everything inside
    for report in weather_report:
        temp_list.append(report.split(','))
    title_list = temp_list.pop(0)

    for report in temp_list:
        #removing \n

        report[-1] = report[-1][:-1]
        #finding greatest temp
        if report[-2] != '':
            if int(report[-2])>max_temp:
                max_temp = int(report[-2])
            #finding lowest temp
        if report[-1] != '':
            if int(report[-1])<min_temp:
                min_temp = int(report[-1])


    print(f'10-year maximum temperature: {max_temp} F')
    print(f'10-year minimum temperature: {min_temp} F')

    print('')

    month = input('Please enter a month: ')
    year = input('Please enter a year: ')

    print('')

    print(f'For {month} {year}:')

    final = mean_calc(list_of_lists(temp_list, month, year))
    print(f'Mean average daily pressure: {final[1]:.2f} in Hg')   
    print(f'Mean average daily temperature: {final[-1]:.1f} F')  
    print(f'Mean average daily wet bulb temperature: {final[2]:.1f} F')  
    print(f'Mean average daily dew point: {final[0]:.1f} F')  
    print(f'Mean average daily relative humidity: {final[-2]:.1f}%')  
    print(f'Mean average daily wind speed: {final[3]:.2f} mph')  
    print(f'Percentage of days with precipitation: {final[-3]:.1f}%')  
    
        

