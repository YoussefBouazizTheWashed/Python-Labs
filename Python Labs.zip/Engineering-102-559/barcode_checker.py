# By submitting this assignment, I agree to the following:
#   "Aggies do not lie, cheat, or steal, or tolerate those who do."
#   "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Youssef Bouaziz
# Section:      559
# Assignment:   Lab Topic 11 Individual
# Date:         October 29 2025

def barcode_valid(compare, first_group, sec_group):
    sum = (first_group) + 3*(sec_group)
    value = str(sum)
    if int(compare) == 10-int(value[-1]):
        return True
    return False

def get_num(the_list):
    compare_value = 10
    num = ['0','1','2','3','4','5','6','7','8','9']
    blank = True
    while blank: 
        if the_list[-1] not in num:
            the_list = the_list[:-1]
        if the_list[-1] in num:
            compare_value = the_list[-1]
            the_list = the_list[:-1]
            blank = False
        

    return the_list,compare_value

valid_barcodes = open('valid_barcodes.txt', 'w')

file = input('Enter the name of the file: ')

with open(file, 'r') as thefile:

    #Need to compare values so we know if barcode is valid


            
         

    # #Where to store the values of the sums of the first and second groups of a singular barcode
    first_group_list = []
    sec_group_list = []
    comparing_value = []

    #Our future sum values of the digits 
    first_group = 0
    sec_group = 0

    z=-1
    y=0

    #finds even numbers from barcode
    for num in thefile:
        # print(num)
        #Grab final value of barcode and seperate the previous number so we have only a string of numbers to work with
        refined_num,compare = get_num(num)
        comparing_value.append(int(compare))
        # print(comparing_value)
        first_group = 0
        sec_group = 0
        # print('This is the barcode before the loop', num)
        for i in range(len(refined_num)):
            # print(len(refined_num))

            #Check if it is an even vlue
            if i%2 == 0:
                # print('a', end='')

                #Appends even digits of refined number
                first_group += int(refined_num[i])

            #Checks if i is an odd value
            if i%2!=0:
                # print('x', end='')


                #Appends odd digit numbers of refined 
                sec_group += int(refined_num[i])
        

        
        #Gets sum of first and second group after the barcode sum for each is calculated.
        first_group_list.append(first_group)
        # print(f'{first_group_list} \n')    
        sec_group_list.append(sec_group)
        # print(f'{sec_group_list}\n')
        z+=1
        # print(comparing_value[z], 'is being compared to', first_group_list[z]+3*sec_group_list[z])
        if barcode_valid(comparing_value[z],first_group_list[z],sec_group_list[z]):
            valid_barcodes.write(num)
            y+=1
    print(f"There are {y} valid barcodes")
valid_barcodes.close()
    
    
    


            

    