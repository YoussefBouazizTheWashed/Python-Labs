# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Youssef Bouaziz
# Section: 559
# Assignment: Lab 12
# Date: 8 November 2025

'''Creating a program that plots a point on a graph by multiplyiing
 a vector and a matrix and then setting the vector eqaul to the product
   of the two and repeat this 250 times'''

import numpy as np
import matplotlib.pyplot as plt

#Manually setting up the vector
vector = np.arange(0,2).reshape(2,1)

#Title for the graph
plt.title('Golden Ratio\n (Cool Spiral Shape)')


#Manually creating matrix
matrix = np.array([[1.02,0.095],
                  [-0.095, 1.02]])

#Labeling Axes
plt.xlabel('x axis')
plt.ylabel('y axis')

#Repeatedly plotting points of multipled matrices
for i in range (250):
    vector = matrix@vector
    plt.scatter(vector[0],vector[1], c = np.random.randint(1,500))
#Finally show the end result graph
plt.show()

