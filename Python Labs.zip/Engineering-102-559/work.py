# --- Given chocolates dictionary (your provided 100 truffles) ---
import random

# === Provided chocolates dictionary ===
chocolates = {
    1: ["milk", "round", "toffee", "sprinkles"],
    2: ["milk", "square", "coconut", "none"],
    3: ["dark", "heart", "strawberry", "white chocolate drizzle"],
    4: ["dark", "round", "toffee", "white chocolate drizzle"],
    5: ["milk", "square", "caramel", "nuts"],
    6: ["milk", "heart", "toffee", "dark chocolate drizzle"],
    7: ["dark", "rectangle", "caramel", "none"],
    8: ["dark", "heart", "strawberry", "white chocolate drizzle"],
    9: ["dark", "heart", "coconut", "white chocolate drizzle"],
    10: ["milk", "square", "coconut", "none"],
    11: ["milk", "round", "vanilla", "dark chocolate drizzle"],
    12: ["milk", "round", "strawberry", "nuts"],
    13: ["milk", "rectangle", "caramel", "sprinkles"],
    14: ["dark", "rectangle", "toffee", "none"],
    15: ["dark", "heart", "toffee", "none"],
    16: ["dark", "heart", "coconut", "white chocolate drizzle"],
    17: ["dark", "round", "vanilla", "none"],
    18: ["dark", "rectangle", "toffee", "dark chocolate drizzle"],
    19: ["milk", "round", "toffee", "none"],
    20: ["milk", "square", "caramel", "dark chocolate drizzle"],
    21: ["milk", "square", "vanilla", "none"],
    22: ["dark", "heart", "caramel", "sprinkles"],
    23: ["milk", "square", "caramel", "nuts"],
    24: ["milk", "round", "caramel", "dark chocolate drizzle"],
    25: ["milk", "round", "coconut", "dark chocolate drizzle"],
    26: ["dark", "round", "coconut", "dark chocolate drizzle"],
    27: ["milk", "rectangle", "strawberry", "sprinkles"],
    28: ["white", "heart", "vanilla", "none"],
    29: ["dark", "heart", "strawberry", "none"],
    30: ["dark", "rectangle", "caramel", "none"],
    31: ["white", "round", "caramel", "none"],
    32: ["milk", "heart", "vanilla", "none"],
    33: ["white", "round", "strawberry", "nuts"],
    34: ["milk", "round", "coconut", "none"],
    35: ["dark", "rectangle", "coconut", "dark chocolate drizzle"],
    36: ["milk", "round", "vanilla", "dark chocolate drizzle"],
    37: ["dark", "round", "coconut", "white chocolate drizzle"],
    38: ["dark", "round", "coconut", "white chocolate drizzle"],
    39: ["dark", "round", "coconut", "dark chocolate drizzle"],
    40: ["dark", "round", "strawberry", "dark chocolate drizzle"],
    41: ["milk", "rectangle", "toffee", "none"],
    42: ["milk", "round", "strawberry", "white chocolate drizzle"],
    43: ["milk", "heart", "coconut", "none"],
    44: ["white", "round", "strawberry", "white chocolate drizzle"],
    45: ["milk", "heart", "toffee", "sprinkles"],
    46: ["milk", "rectangle", "strawberry", "none"],
    47: ["white", "round", "caramel", "dark chocolate drizzle"],
    48: ["white", "square", "toffee", "none"],
    49: ["milk", "rectangle", "toffee", "none"],
    50: ["dark", "rectangle", "caramel", "none"],
    51: ["milk", "square", "vanilla", "none"],
    52: ["dark", "round", "toffee", "dark chocolate drizzle"],
    53: ["milk", "round", "toffee", "white chocolate drizzle"],
    54: ["dark", "square", "strawberry", "none"],
    55: ["milk", "heart", "caramel", "dark chocolate drizzle"],
    56: ["milk", "heart", "vanilla", "none"],
    57: ["milk", "heart", "caramel", "none"],
    58: ["milk", "heart", "coconut", "sprinkles"],
    59: ["milk", "heart", "vanilla", "sprinkles"],
    60: ["dark", "square", "caramel", "none"],
    61: ["milk", "rectangle", "vanilla", "none"],
    62: ["milk", "heart", "toffee", "none"],
    63: ["milk", "heart", "vanilla", "dark chocolate drizzle"],
    64: ["white", "round", "coconut", "white chocolate drizzle"],
    65: ["milk", "round", "coconut", "nuts"],
    66: ["milk", "round", "coconut", "white chocolate drizzle"],
    67: ["dark", "heart", "coconut", "none"],
    68: ["dark", "square", "toffee", "none"],
    69: ["dark", "round", "strawberry", "dark chocolate drizzle"],
    70: ["milk", "heart", "caramel", "none"],
    71: ["milk", "square", "caramel", "sprinkles"],
    72: ["milk", "rectangle", "strawberry", "sprinkles"],
    73: ["dark", "heart", "strawberry", "none"],
    74: ["dark", "heart", "strawberry", "none"],
    75: ["dark", "square", "coconut", "none"],
    76: ["dark", "heart", "caramel", "none"],
    77: ["dark", "heart", "coconut", "nuts"],
    78: ["white", "rectangle", "caramel", "dark chocolate drizzle"],
    79: ["milk", "heart", "vanilla", "sprinkles"],
    80: ["white", "heart", "strawberry", "none"],
    81: ["dark", "round", "toffee", "white chocolate drizzle"],
    82: ["dark", "round", "vanilla", "none"],
    83: ["white", "square", "coconut", "none"],
    84: ["milk", "rectangle", "caramel", "dark chocolate drizzle"],
    85: ["white", "heart", "toffee", "none"],
    86: ["white", "round", "caramel", "nuts"],
    87: ["white", "round", "caramel", "none"],
    88: ["dark", "round", "caramel", "none"],
    89: ["dark", "square", "coconut", "nuts"],
    90: ["milk", "heart", "vanilla", "none"],
    91: ["dark", "round", "coconut", "none"],
    92: ["dark", "round", "caramel", "none"],
    93: ["white", "round", "toffee", "none"],
    94: ["milk", "round", "vanilla", "sprinkles"],
    95: ["white", "round", "strawberry", "white chocolate drizzle"],
    96: ["dark", "square", "strawberry", "nuts"],
    97: ["milk", "round", "vanilla", "none"],
    98: ["milk", "rectangle", "caramel", "sprinkles"],
    99: ["milk", "heart", "vanilla", "none"],
    100: ["dark", "rectangle", "strawberry", "white chocolate drizzle"]
}



def make_boxes(chocolates):
    from itertools import combinations

    def is_valid_box(truffle_ids):
        fillings = set()
        toppings = set()
        shapes = set()
        dark_count = 0

        for tid in truffle_ids:
            choco, shape, filling, topping = chocolates[tid]
            fillings.add(filling)
            toppings.add(topping)
            shapes.add(shape)
            if choco == "dark":
                dark_count += 1

        # Constraint checks
        if "caramel" in fillings and "vanilla" in fillings:
            return False
        if "nuts" in toppings and "sprinkles" in toppings:
            return False
        if "square" in shapes and "rectangle" in shapes:
            return False
        if dark_count > 0 and (dark_count < 2 or dark_count > 3):
            return False

        return True

    used = set()
    boxes = []

    # Try all combinations of 4 truffles
    for combo in combinations(chocolates.keys(), 4):
        if any(tid in used for tid in combo):
            continue
        if is_valid_box(combo):
            boxes.append(list(combo))
            used.update(combo)
        if len(boxes) == 25:
            break

    return boxes

boxes = make_boxes(chocolates)

print(boxes)