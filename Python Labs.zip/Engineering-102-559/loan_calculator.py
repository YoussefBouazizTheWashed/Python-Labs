# By submitting this assignment, I agree to the following:
#   "Aggies do not lie, cheat, or steal, or tolerate those who do."
#   "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Youssef Bouaziz
# Section:      559
# Assignment:   Lab Topic 11 Individual
# Date:         October 29 2025


file_name = input('Enter the output filename: ')
principle = float(input('Enter the principal amount: '))
num_of_month = int(input('Enter the term length (months): '))
annual_interest_rate = float(input('Enter the annual interest rate: '))

#Just so I have a contsant value of the principle
temp_principle = principle

#create file to write in
file = open(file_name, 'w')
#Set monthly interest to zero in advance
total_monthly_interest = 0.00
monthly_interest = 0


#Write out the constant data for the .cvs file
file.write('Month,Total Accrued Interest,Loan Balance\n')

file.write(f'{0},${monthly_interest:.2f},${temp_principle:.2f}\n')
for month in range(1,num_of_month+1):

    
    
    monthly_payment = temp_principle*(annual_interest_rate/12)/(1-(1/(1+(annual_interest_rate/12)))**num_of_month)
    # print(monthly_payment)
    #Check whether month is zero to prevent division by zero
    if principle!=0:
        #Monthly interest equation
        monthly_interest= principle*(annual_interest_rate/12)
        total_monthly_interest += monthly_interest
        #Principle subtracted by the payment made that month!
        principle-= (monthly_payment-monthly_interest)
        # print(principle)
        if principle<0.01:
            principle = 0.00
        file.write(f'{month},${total_monthly_interest:.2f},${principle:.2f}\n')
file.close