import turtle as t
from PIL import Image as img
import math as m



img1 = img.open("OIP.jpg")
img1.save("OIP.gif")
size = (1500,1200)
newimage = img1.resize(size)
newimage.save("OIP.gif")
# img2 = img.open("Turkey.jpg")
# resize_img2 = img2.resize((300,300))
# resize_img2.save("Turkey.gif")

# Only accepts sizes divisble by 180
t.showturtle()
t.tracer(0)


def text():
    '''Create Text on billboard'''
    t.penup()
    t.goto(-250,80)
    t.color('maroon')
    t.write("3AT", font=("Comic Sans MS", 36, "bold"))
    t.goto(-100,0)
    t.color('yellow')
    t.write("MUR", font=("Comic Sans MS", 36, "bold"))
    t.goto(100,-80)
    t.color('orange')
    t.write("HAM", font=("Comic Sans MS", 36, "bold"))
    t.pendown()

t.tracer(2) #  the speed the turtle draws at

'''Turkey Neck'''
def turkey_neck():
    t.hideturtle() #  hides the arrow
    t.color("red", "#89cff0")  # sets the turtle color to red and the fill color to blue
    t.setheading(265) #  turns the direction of the turtle downward
    for i in range(5, 25): #  this loop make the pensize bigger as it moves forward
        t.pensize(i) #  pensize varies per iteration
        t.forward(4)
    t.pensize(30) #  Set the new pensize
    t.forward(1)

    t.update()
      

def head(radius):
    t.fillcolor("#89cff0")
    t.begin_fill()
    t.circle(radius)
    t.end_fill()
    t.penup()

    t.pendown()
    t.right(45)
    t.fillcolor("orange")
    t.begin_fill()
    t.forward(radius/2)
    t.right(45)
    t.forward(-radius/2)
    t.end_fill()

    t.penup()
    t.left(135)
    t.forward(radius/2)
    t.left(90)
    t.forward(radius/10)
    t.pendown()
    t.dot(radius/5, "black" )
    t.penup()
    t.right(90)
    t.back(radius)
    t.pensize(25)
    t.pencolor("red")
    t.right(90)
    t.back(radius/4)
    t.pendown()
    t.back(radius/4)
    t.left(45)
    t.back(radius/4)


    





'''Feathers'''
def turkey_feathers():
    t.color("black", "#3E2723")   #  (pen color, fill color)
    t.goto(0, 0)
    t.begin_fill()

    t.setheading(10)
    t.tracer(7)
    t.forward(100)
    for i in range(240):
        t.left(.5)
        t.forward(.5)
    t.goto(0, 0)

    t.setheading(170)
    t.forward(100)
    for i in range(240):
        t.right(.5)
        t.forward(.5)
    t.goto(0, 0)

    t.setheading(90)
    t.forward(100)
    for i in range(240):
        t.right(.5)
        t.forward(.5)
    t.goto(0, 0)

    t.setheading(90)
    t.forward(100)
    for i in range(240):
        t.left(.5)
        t.forward(.5)
    t.goto(0, 0)

    t.update()
    t.end_fill()

'''Paint Brush'''
def turkey_brush():
        t.penup()
        t.goto(-100,-110)
        t.pendown()
        t.tracer(1)
        t.color("#D2B48C")  #  (pen color)
        t.hideturtle()
        t.pensize(10)
        t.setheading(60)
        t.forward(40)
        t.pencolor("gray")
        t.forward(20)

        t.pencolor("#4E342E")
        for i in range(18,0,-1):
            t.pensize(i)
            t.forward(1)

        t.update()
        t.end_fill()

def drawFeathers(length, thickness):
    '''This will draw the tail feathers of the turkey'''
    t.speed(0)
    #  biggest layer of feathers
    for i in range(7):
        t.color("orange")
        t.pensize(thickness)
        t.forward(length)
        t.back(length)
        t.left(30)
    t.right(30)
    
    #  middle layer of feathers
    for j in range(7):
        t.color("tan")
        t.pensize(thickness * 0.8)
        t.forward(length * 0.8)
        t.back(length * 0.8)
        t.right(30)
    t.left(30)
    
    #  smallest layer of feathers
    for k in range(7):
        t.color("#8B4513")
        t.pensize(thickness * 0.6)
        t.forward(length * 0.7)
        t.back(length * 0.7)
        t.left(30)
    
    #  resetting pen
    t.right(30)
    t.color("black")
    t.pensize(1)
    t.penup()

'''Draw Body'''
def drawBody():
    #  Body
    t.fillcolor("brown")
    t.begin_fill()
    t.circle(80)
    t.end_fill()

    t.color('gray')
    t.pensize(5)
    #  Right Leg
    t.penup()
    t.left(5)
    t.forward(25)
    t.right(60)

    t.pendown()
    t.forward(50)
    t.left(180)

    #  Left Leg
    t.penup()
    t.forward(50)
    t.left(55)
    t.forward(50)
    t.left(60)
    t.pendown()
    t.forward(50)

    #  Right Arm
    t.penup()
    # t.goto(78, 100)
    t.right(190)
    t.forward(192)
    # t.right(90)
    t.pendown()
    t.forward(80)

    #  Left Arm
    t.penup()
    # t.goto(-78, 100)
    t.left(150)
    t.forward(215)

    t.pendown()
    t.forward(80)

    t.pensize(1)
    t.color("black")

screen = t.Screen()
screen.bgpic("OIP.gif")
t.penup()
t.forward(-225)
t.right(90)
t.forward(280)
t.left(90)
t.pendown()
drawBody()


#turkey_feathers()
t.penup()

t.forward(-200)
t.right(135)
t.forward(50)
t.pendown()
head(50)
turkey_brush()
t.penup()
t.goto(-230,-230)
t.pendown()
t.setheading(0)
drawFeathers(100, 50)


text()


t.update()
# head(50)



# file = open("Turkey.svg", 'r')
# data =file.read()

# print(data)






# turt_one = t.Turtle()
# turt_one.shape("Turkey.gif")
# turt_one.forward(100)

# turt_one.hideturtle()
# screen.register_shape("Turkey.gif")
print('Youssef is thankful for the kind engineering teacher he has!')
print('Niko is thankful for his family friends!')
print('Hollis is thankful for being American.')
print('Steven is thankful for his health, loved ones, and pizza!')

t.done()



