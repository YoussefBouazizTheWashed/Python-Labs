# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Youssef Bouaziz
# Section: ENGR-102-559
# Assignment: Lab 5.5
# Date: 15/9/2025

import math

heat = 1

#Our points
y0 = 1000
x0 = 1.3
y1 = 7000
x1 = 5
y2 = 1500000
x2 = 30
y3 = 25000
x3 = 120
y4 = 1500000
x4 = 1200




#The four slopes we will be using
m1 = (math.log10(y1/y0)/math.log10(x1/x0))
m2 = (math.log10(y2/y1)/math.log10(x2/x1))
m3 = (math.log10(y3/y2)/math.log10(x3/x2))
m4 = (math.log10(y4/y3)/math.log10(x4/x3))


#Our user
Value = float(input('Enter the excess temperature: '))

#Example of Formula for Y value
#y = int(round(1000*(Value/1.3)**m1))

if Value <= x1 and Value > 0:
    y = int(round(y0*(Value/x0)**m1))
    print(f'The surface heat flux is approximately {y} W/m^2')
elif Value <= x2 and Value > 0:
    y = int(round(y1*(Value/x1)**m2))
    print(f'The surface heat flux is approximately {y} W/m^2')
elif Value <= x3 and Value > 0:
    y = int(round(y2*(Value/x2)**m3))
    print(f'The surface heat flux is approximately {y} W/m^2')
elif Value <= x4 and Value > 0:
    y = int(round(y3*(Value/x3)**m4))
    print(f'The surface heat flux is approximately {y} W/m^2')
else:
    print('Surface heat flux is not available')