#My goal is to create my own personal calendar that can be attached 
# to excel
#Which has ease of access instead of manually creating my own

#I want to do this so I can, One: increase my python skills, 
#and Two: so that I have a go-to orginizational tool
#I hope that this can help me pass the class, I just have to keep trying 
# and 
# NEVER GIVE UP



#Setting to global as we will use this many times!
global day_in_week
global numbers
#Our days of the week
day_in_week = ['monday', 'tuesday','wednesday', 'thursday','friday','saturday','sunday']
numbers = ['0','1','2','3','4','5','6','7','8','9']


def valid_day(day):
    '''Checks for valid day and returns boolean'''
    is_True = False

    for test in day_in_week:
        if day.lower() not in test:
            print(day)
            continue
        else:
            print(day+'!')
            is_True = True
            break
    
    return is_True,test


def valid_time(time):
    test_time = list(time)

    am_pm = ['am', 'pm']
    #Checking for am or pm
    if ''.join(test_time[-2:]).lower() in am_pm:
        ###Rememebr for future###
        time_of_day = test_time[-2:]

        #Removing am or pm
        test_time = test_time[:-2]
        #Testing Length and colon placement
        if len(test_time)==5 and (test_time[2] == ':'):
            #Removing colon
            test_time.pop(2)
            #Check if remaining list is actually numbers
            for z in test_time:
                if z not in numbers:
                    return False
                
            return True
        #Checks Length and if colon is present
        elif len(test_time)==4 and (test_time[1] == ':'):

            #Removes colon
            test_time.pop(1)
            #Checks if remaining list is numbers
            for i in test_time:
                if i not in numbers:
                    return False
                
            return True
    return False

file = open('Calendar.csv', 'r+')



#Attaching Important times to days
def day_plan(day, time):
    '''Checks if the input is a valid day and if so returns a tuple 
    with a boolean and a dictionary'''
    time = {}

    if valid_day(day)

        


# with open('calendar.txt', 'r+') as calendar:
#     input('Come to do your weekly schedule have you?')
#     input('Well you finna get straight A\'s twin')

    
#     empty_cal = {}
#     # time_number = 0
#     # second = 60
#     # minute = 60*second
#     # hour = 1*minute
#     # day = 24*hour

#     temp_list = []
    
        

#     for i in (0,7):
#         #Putting days in week for calendar
#         empty_cal[day_in_week[i]] = []
#     #Confirming user input to erase previou calendar!
#     new_cal = input('Are you setting up a new schedule for the week?(Yes or No)')
#     confirm = input('Are you sure this will erase your previous calendar')
    

#     ask = ''
#     if new_cal.lower() and confirm.lower() in ['yes', 'yeah', 'ok', 'sure', 'why not','y','ye','yea']:
#         for i in (len(empty_cal)):
#             #Calling day in the week key and giving it a value(time)
            
#             empty_cal[day_in_week[i]] = time
    