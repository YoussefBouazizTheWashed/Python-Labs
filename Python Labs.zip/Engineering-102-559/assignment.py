# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Youssef Bouaziz
# Section: 559
# Assignment: lab 12
# Date: 2 December 2025
# with open('grades.txt', 'w') as f:
#     f.write('Alice: 85\nBob: 90\nCharlie: 78\nDiana: 92\nEthan: 88')

# grades = [y for y in open('grades.txt', 'r')
# .read().split('\n') ]

# final = []
# for i in grades:
#     x = i.split(':')
#     final.append(int(x[1]))
    
# print(max(final), min(final), sum(final)/len(final))
# import numpy as np

# final = []

# import numpy as np

# title = [y for y in open('grades.txt', 'r').readlines()[:3]]
# sad = [z for y in open('grades.txt', 'r').readlines()[3:] for z in y.strip().split(',')]
# print(sad)
# happy = (np.array(sad).reshape(len(sad)//3, 3))
# f,g = [], []
# for i in happy:
#     f.append(float(i[1]))
#     g.append(float(i[2]))

# print(max(g), min(f))


# x = open('grades.txt', 'r').readlines()[1:]
# for i in open('grades.txt', 'r').readlines()[0].strip().split():
#     print(i, end=' ')
# print('Ratio')


# y = [i.strip().split() for i in x]

# for i in y:
#     print(f'{i[0]} {i[1]} {i[2]} {float(i[1])/float(i[2])}') 


# y = [{x.strip().split(': ')[0]:x.strip().split(': ')[1]} for x in open('grades.txt', 'r').readlines()]
# count = 0
# string = ''
# for f in y: 
#     for key, value in f.items():

#         count+= value.count('flounder')
#         for i,char in enumerate(value.strip().split(', ')):
#             if 'flounder' in char and i==0:
#                 string += f'{key}: {value.split(', ')[i]}'
#             elif 'flounder' in char:
#                 string += f', {value.split(', ')[i]}'
#         string+='\n' 
# print(string)
# print(f'Total {count} flounders caught')

       












