# By submitting this assignment, I agree to the following:
#   "Aggies do not lie, cheat, or steal, or tolerate those who do."
#   "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Youssef Bouaziz
# Section:      559
# Assignment:   Lab Topic 11 Individual
# Date:         Novemeber 1 2025

with open('WeatherDataCLL.csv', 'r+') as weather_data:
    print(weather_data.read())
