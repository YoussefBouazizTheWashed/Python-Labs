# t = [1,2,3,4,5,6]

# try:
#     t[10].append(4)
# except IndexError:
#     print('no')

# file = open('scanned_passports.txt', 'r+')

# data = list(file.read())
# better_data = ''.join(data).split('\n\n')
# print(better_data[0])

a, b = 3, 0
countStr = "" # empty string
    while a > b:
        try:
            c = a / b
            countStr += str(a)
        except:
            countStr += str(b)
            a -= 1
countList = list(countStr)
for i in range(len(countList)):
countList[i] = float(countList[i])
print(sum(countList), countList.count(0), sep=":", end="!")



