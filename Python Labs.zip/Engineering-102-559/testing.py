# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Youssef Bouaziz
# Names: Carlseton Wilkens
# Names: Ridocc Murray
# Names: Edgar 
# Section: 559
# Assignment: Lab 11: Passport Checker
# Date: 2 December 2025

# birthdays = [((input(f'User {i+1}, enter your birthday: ') for i in range(5)).strip().split()).split]

# birthdays = []

# for i in range(5):
#     e = input(f'User {i+1}, enter your birthday: ')
#     f = e.split()
#     birthdays.append([f[0], int(f[1])])

# months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
# birthdays_sorted = []

# for i,time in enumerate(birthdays):
#     print(i, time)

#     month, day  = time
#     month_index = months.index(month[:3].lower())
#     birthdays_sorted.append([month_index, day, {month: day}])

# # print(birthdays_sorted)
# birthdays_sorted.sort()

# mandatory_dict = {}
# for i in birthdays_sorted:
#     for key, value in i[2].items():
#         mandatory_dict[key] = value
#         print(f'{key} {value}') 





# for key, value in {'a': 1, 'b': 2, 'c':3, 'd':4}.items():
#     print(key, value)

# a = 'fyrhfiednvjnvibebeff'

# print(a.count('f'))

# a = [1,2,3,4,5,6,7,8,9,1,1,1,1,1,1,1,1,1,1,1,1,1]
# print(a.count(1))

##########################################################################################################################################
# letters = [0,0,'abc', 'def', 'ghi', 'jkl', 'mno', 'pqrs', 'tuv', 'wxyz']

# dict_letters = {}
# letter_list = []
# for i in range(2,10):
#     count = 0
#     string = ''
#     while count < len(letters[i]):
#         string+= (letters[i][count]).upper()
#         print(letters[i][count])
#         count+=1
#     dict_letters[i] = string
    
    
# number = input('Enter a number in this format XXX-XXXXXXX: ')


# final_string = ''
# sepNum = number.strip().split('-')
# for Letter in sepNum[1]:
#     for place in dict_letters:
#         if Letter.upper() in dict_letters[place]:
#             final_string+=str(place)
            
# print(f'{number} is equivelant to {sepNum[0]}-{final_string[:3]}-{final_string[3:]}')

##########################################################################################################################################

# inputs = input('Enter a number of patients: ')

# temp_list = []

# for i in range(int(inputs)):
#     info = input('Enter the next name and information: ')
#     temp_list.append(info.split())

# the_dict = {}

# for i in temp_list:
#     string = ''
#     BloodP = i[1]
#     Pulse = i[2]
#     BloodG = i[3]
#     string+= 'Blood Pressure: ' + BloodP + ', Pulse: ' + Pulse + ', Blood Glucose: ' + BloodG
#     the_dict[i[0]] = string

# name = input('Enter a name: ')

# for key, value in the_dict.items():
#     if name.lower() == key.lower():
#         print(f'Here is the information for {key}:\n{value}')
#         break

############################################################################################################################################

# nextfile = open("afile2.csv", "w")
# nextfile.write("\t".join("1,2,3\n".split(",")))
# nextfile.write("\t".join("4,5,6\n".split(",")))
# list1 = ".".join(["5", "6", "7", "8", "9"])
# nextfile.write(list1)
# nextfile.close()
# import numpy as np

# y = [i.strip().split(' ') for i in open('grades.txt', 'r').readlines()]

# sum = 0

# for r in y: 
#     a = ''.join(r)
#     if len(a)> sum:
#         print(a)
#         sum = len(a)
# print(sum)

# a = [1,2,3,4,5,6,5,4,323,76,34235,8097,2,34,23,6]

# def mean(num):
#     joe = 0
#     for i in range(len(num)):
#         joe+=(num[i]-sum(num)/len(num))**2
#     joe = (joe/len(num))
#     return sum(num)/len(num), joe
# print(mean(a))


