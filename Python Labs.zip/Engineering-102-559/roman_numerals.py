# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Youssef Bouaziz
# Section: 559
# Assignment: Lab 10.15
# Date: 10/20/2025

def is_empty(s):  # Takes value
    return len(s) == 0  # If nothing in list value then TRUE


def from_roman(roman_numeral):
    '''
    In the Roman numeral system, the symbols I, V, X, L, C, D, and M stand
    respectively for 1, 5, 10, 50, 100, 500, and 1,000 in the Hindu-Arabic
    numeral system.
    A symbol placed previous another of equal or greater value
    adds its value.
    A lesser symbol placed before one of greater value subtracts its #Error with the description
    value.
    '''

    #D and C values are have incorrect values for the roman numeral system
    symbols = {'I': 1, 'V': 5, 'X':
        10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    

    if is_empty(roman_numeral): #If there is no value in parameter
        return 0
    if len(roman_numeral) == 1: #If length of user's parameter input roman numerals is 1
        return symbols[roman_numeral[0]] #Error occurs when conditional is met
    symbol = roman_numeral[-1]
        #print(symbol) - Test case
    decimal_value = symbols[symbol]
        #print(symbols[symbol]) - Test case
    previous_symbol = symbol #Incorrectly named also redundant
        #print(previous_symbol) - Test case


    for i in range(1, len(roman_numeral)): #Missing colon

        if symbols[roman_numeral[-1 - i]] >= symbols[previous_symbol]:
            # print('i value', i)
            # print('decimal value before adding:', decimal_value)
            decimal_value += symbols[roman_numeral[-1 - i]]
            previous_symbol = roman_numeral[-1 - i]
            # print('decimal value after adding', decimal_value)
        else:
            decimal_value -= symbols[roman_numeral[-1 - i]] #Symbol is not
            previous_symbol = roman_numeral[-1 - i]


    return decimal_value #Bad indentation(prints value prematurely by ending loop after first iteration)
def compare_roman_numerals(roman_numeral_1, roman_numeral_2):
    a = from_roman(roman_numeral_1)
    b = from_roman(roman_numeral_2)
    # print(a,b)
    if a < b:
        return -1
    elif a == b: #Wrong code should return zero when a and b are equal to each other.
        return 0
    return 1

# print(compare_roman_numerals('VII', 'VIII'))

def main():
    num1 = input("Enter the first Roman numeral: ")
    num2 = input("Enter the second Roman numeral: ")
    result = compare_roman_numerals(num1, num2)
    if result == -1:
        compare = 'smaller than'
    elif result == 0:
        compare = 'equal to'
    else:
        compare = 'larger than'
    print(f'{num1} is {compare} {num2}') #Parenthesis at the end

if __name__ == '__main__':
    main()