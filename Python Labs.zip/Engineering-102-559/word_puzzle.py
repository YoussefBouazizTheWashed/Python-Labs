



# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Niko Hu
# Names: Hollis Harlan
# Names: Youssef Bouaziz
# Names: Steven Talbott
# Section: 559
# Assignment: Lab 9: Word Puzzle
# Date: 21 October 2025
''' Asks for a word puzzle, displays it, then prompts the user to solve.
    Tells if the user's guess was invalid, incorrect, or correct.'''


def print_puzzle(puzzle):
    ''' Print puzzle as a long division problem.
        Inputs:
            puzzle: String that contains the word arithmetic puzzle
        Output: none '''
    puzzle = puzzle.split(',')
    for i in range(len(puzzle)):
        if i == 1:
            print(f'{len(puzzle[i].split("|")[1]) * "_": >16}')
        print(f'{puzzle[i]: >16}')
        if i > 1 and i % 2 == 0:
            print(f"{'-' * len(puzzle[i]): >16}")


def get_valid_letters(puzzle):
    ''' Determines all (10) unique letters in the given word arithmetic puzzle.
        Inputs:
            puzzle: String that contains the word arithmetic puzzle
        Output: String containing all (10) unique letters'''
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    unique_letters = ""
    # Check if each letter in puzzle is in unique_letters, if it isn't, add it to unique_letters
    for i in range(len(puzzle)):
        if puzzle[i] in letters and not puzzle[i] in unique_letters:
            unique_letters += puzzle[i]
    return unique_letters


def is_valid_guess(valid_letters, user_guess):
    ''' Determines if a user's guess contains only all 10 unique letters in the word arithmetic puzzle.
        Inputs:
            valid_letters: String containing all (10) unique letters
            user_guess: String containing the user's guess for the solution of the word arithmetic puzzle
        Output: True if the user's guess if valid, False if not'''
    # Check that user_guess contains 10 letters
    if len(user_guess) != 10:
        return False
    # Check that all letters in user_guess are also in valid_letters
    for i in range(len(user_guess)):
        if user_guess[i] not in valid_letters:
            return False
    # Check that there are no duplicate letters
    for j in range(len(user_guess) - 1):
        if user_guess[j] in user_guess[:j] or user_guess[j] in user_guess[j + 1:]:
            return False
    # Passing all, true
    return True


def check_user_guess(dividend, quotient, divisor, remainder):
    ''' Checks if the numbers created using the user's guess are correct.
        Inputs:
            dividend: Integer representing the dividend value calculated using the user's guess
            quotient: Integer representing the quotient value calculated using the user's guess
            divisor: Integer representing the divisor value calculated using the user's guess
            remainder: Integer representing the remainder value calculated using the user's guess
        Output: True if the guess was correct, False if not'''
    return dividend == quotient * divisor + remainder  # returns true boolean value if dividend is equal to the quotient times the divisor plus the remainder


def make_number(word, user_guess):
    ''' Uses the user's guess as a key to convert a word into a number, with the user's letters representing numbers 0-9.
        Inputs:
            word: String containing the word to be converted
            user_guess: String containing the user's guess to be used as a key 0-9
        Output: Integer value of the word'''
    word_value = 0
    # Adds the value of each letter multiplied by 10 for each space from the right it is
    for i in range(len(word)):
        word_value *= 10
        for j in range(len(user_guess)):
            if user_guess[j] in word[i]:
                word_value += j
    return word_value



def make_numbers(puzzle, user_guess):
    ''' Pulls the dividend, quotient, divisor, and remainder words from the word arithmetic puzzle
        and converts them into numbers using the user's guess as a key.
        Inputs:
            puzzle: String containing the word arithmetic puzzle
            user_guess: String containing the user's guess
        Output: Tuple containing 4 Integers, the dividend, quotient, divisor, and remainder values'''
    split_puzzle = puzzle.split(",")  # split the puzzle into words, with sub 1 having the divisor and dividend
    split_puzzle[1:2] = split_puzzle[1].split(" | ")  # insert and replace sub 1 the divisor and dividend
    dividend = make_number(split_puzzle[2], user_guess)  # assign the number values of the dividend, quotient, divisor, and remainder
    quotient = make_number(split_puzzle[0], user_guess)
    divisor = make_number(split_puzzle[1], user_guess)
    remainder = make_number(split_puzzle[-1], user_guess)
    return (dividend, quotient, divisor, remainder)


def main():
    ''' Takes the word arithmetic puzzle as input from the user, displays the puzzle,
       and asks the user to enter a guess, then display an appropriate message.
       Inputs: none
       Outputs: none'''

    # Prompt the user for the word arithmetic puzzle, display it, and get the valid letters
    puzzle_string = input('Enter a word arithmetic puzzle: \n')
    print_puzzle(puzzle_string)
    valid_letters = get_valid_letters(puzzle_string)

    # Prompt the user for their guess, check if it's valid, correct, or incorrect and display accordingly
    puzzle_guess = input('\nEnter your guess, for example ABCDEFGHIJ: ')
    if not (is_valid_guess(valid_letters, puzzle_guess)):
        print('Your guess should contain exactly 10 unique letters used in the puzzle.')
        print(make_number(puzzle_string, puzzle_guess))
    else:
        numbers = make_numbers(puzzle_string, puzzle_guess)
        print(numbers)
        if (check_user_guess(numbers[0], numbers[1], numbers[2], numbers[3])):
            print('Good job!')
        else:
            print('Try again!')

if __name__ == "__main__":
    main()