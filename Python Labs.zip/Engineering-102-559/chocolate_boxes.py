# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Youssef Bouaziz
# Section: ENGR-102-559
# Assignment: Lab 5.5
# Date: 15/9/2025

# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names: Niko Hu
# Names: Hollis Harlan
# Names: Youssef Bouaziz
# Names: Steven Talbott
# Section: 559
# Assignment: Lab 10: Chocolate Boxes
# Date: 27 October 2025


def make_boxes(chocolates):
    """
    Create 25 boxes of 4 truffles each that satisfy all constraints:
    - No two identical truffles in the same box
    - No box with both caramel and vanilla
    - No box with both nuts and sprinkles
    - No box with both rectangles and squares
    - Boxes with dark chocolate must have 2-3 dark chocolate truffles
    """
    import random

    def is_valid_box(truffle_ids):
        """Check if a box of 4 truffles satisfies all constraints"""
        if len(truffle_ids) != 4:
            return False

        truffles = [chocolates[tid] for tid in truffle_ids]

        # Check for duplicates
        if len(set(tuple(t) for t in truffles)) != 4:
            return False

        # Extract attributes
        types = [t[0] for t in truffles]
        shapes = [t[1] for t in truffles]
        fillings = [t[2] for t in truffles]
        toppings = [t[3] for t in truffles]

        # No box with both caramel and vanilla fillings
        if "caramel" in fillings and "vanilla" in fillings:
            return False

        # No box with both nuts and sprinkles toppings
        if "nuts" in toppings and "sprinkles" in toppings:
            return False

        # No box with both rectangles and squares
        if "rectangle" in shapes and "square" in shapes:
            return False

        # Dark chocolate constraint: if any dark, must have 2-3 dark
        dark_count = types.count("dark")
        if dark_count == 1 or dark_count == 4:
            return False

        return True

    def can_add_to_box(box, new_id):
        """Check if adding a truffle to a partial box could lead to a valid box"""
        if new_id in box:
            return False

        test_box = box + [new_id]
        truffles = [chocolates[tid] for tid in test_box]

        # Check for duplicates
        if len(set(tuple(t) for t in truffles)) != len(truffles):
            return False

        # Extract attributes
        types = [t[0] for t in truffles]
        shapes = [t[1] for t in truffles]
        fillings = [t[2] for t in truffles]
        toppings = [t[3] for t in truffles]

        # Check conflicting fillings
        if "caramel" in fillings and "vanilla" in fillings:
            return False

        # Check conflicting toppings
        if "nuts" in toppings and "sprinkles" in toppings:
            return False

        # Check conflicting shapes
        if "rectangle" in shapes and "square" in shapes:
            return False

        # Check dark chocolate constraint
        dark_count = types.count("dark")
        if len(test_box) == 4:
            if dark_count == 1 or dark_count == 4:
                return False
        else:
            # If partial box, check if it's still possible to satisfy constraint
            if dark_count == 1:
                # Need to add more dark chocolates
                remaining = 4 - len(test_box)
                if dark_count + remaining < 2:  # Can't reach 2
                    return False
            elif dark_count >= 4:
                return False

        return True

    # Strategy: Group truffles by constraints and build boxes intelligently
    available = set(chocolates.keys())
    boxes = []

    # Categorize truffles
    dark_truffles = [tid for tid in available if chocolates[tid][0] == "dark"]
    non_dark_truffles = [tid for tid in available if chocolates[tid][0] != "dark"]

    random.shuffle(dark_truffles)
    random.shuffle(non_dark_truffles)

    max_attempts = 100

    for attempt in range(max_attempts):
        if len(boxes) == 25:
            break

        # Reset if we're stuck
        if attempt > 0 and attempt % 10 == 0:
            boxes = []
            available = set(chocolates.keys())
            dark_truffles = [tid for tid in available if chocolates[tid][0] == "dark"]
            non_dark_truffles = [tid for tid in available if chocolates[tid][0] != "dark"]
            random.shuffle(dark_truffles)
            random.shuffle(non_dark_truffles)

        boxes = []
        available_list = list(chocolates.keys())
        random.shuffle(available_list)
        used = set()

        # Build 25 boxes
        while len(boxes) < 25 and len(used) < 100:
            box = []
            candidates = [tid for tid in available_list if tid not in used]

            if len(candidates) < 4:
                break

            # Try to build a box
            for tid in candidates:
                if len(box) >= 4:
                    break

                if can_add_to_box(box, tid):
                    box.append(tid)

            # If we got a valid box, keep it
            if len(box) == 4 and is_valid_box(box):
                boxes.append(box)
                used.update(box)
            else:
                # Try a different starting point
                break

        if len(boxes) == 25:
            return boxes

    # If random approach didn't work, try a more structured approach
    boxes = []
    used = set()
    all_ids = list(chocolates.keys())

    for box_num in range(25):
        available = [tid for tid in all_ids if tid not in used]

        if len(available) < 4:
            break

        # Try many random combinations
        best_box = None
        for _ in range(1000):
            random.shuffle(available)
            box = []

            for tid in available:
                if len(box) >= 4:
                    break
                if can_add_to_box(box, tid):
                    box.append(tid)

            if len(box) == 4 and is_valid_box(box):
                best_box = box
                break

        if best_box:
            boxes.append(best_box)
            used.update(best_box)
        else:
            # Couldn't find a valid box, start over with different seed
            return make_boxes_deterministic(chocolates)

    if len(boxes) == 25:
        return boxes

    return make_boxes_deterministic(chocolates)


def make_boxes_deterministic(chocolates):
    """Fallback deterministic approach"""
    import random

    def is_valid_box(truffle_ids):
        if len(truffle_ids) != 4:
            return False

        truffles = [chocolates[tid] for tid in truffle_ids]
        if len(set(tuple(t) for t in truffles)) != 4:
            return False

        types = [t[0] for t in truffles]
        shapes = [t[1] for t in truffles]
        fillings = [t[2] for t in truffles]
        toppings = [t[3] for t in truffles]

        if "caramel" in fillings and "vanilla" in fillings:
            return False
        if "nuts" in toppings and "sprinkles" in toppings:
            return False
        if "rectangle" in shapes and "square" in shapes:
            return False

        dark_count = types.count("dark")
        if dark_count == 1 or dark_count == 4:
            return False

        return True

    from itertools import combinations

    all_ids = list(chocolates.keys())
    used = set()
    boxes = []

    # Try to greedily find valid boxes
    for box_num in range(25):
        available = [tid for tid in all_ids if tid not in used]

        if len(available) < 4:
            break

        # Try combinations in a smart order
        found = False

        # Limit combinations to check
        random.shuffle(available)
        check_limit = min(len(available), 20)

        for combo in combinations(available[:check_limit], 4):
            if is_valid_box(list(combo)):
                boxes.append(list(combo))
                used.update(combo)
                found = True
                break

        if not found:
            # Try with more candidates
            for combo in combinations(available[check_limit:], 4):
                if is_valid_box(list(combo)):
                    boxes.append(list(combo))
                    used.update(combo)
                    found = True
                    break

        if not found:
            break

    return boxes if len(boxes) == 25 else None


# Test with the provided example
if __name__ == "__main__":
    chocolates = {1: ["milk", "round", "toffee", "sprinkles"],
    2: ["milk", "square", "coconut", "none"],
    3: ["dark", "heart", "strawberry", "white chocolate drizzle"],
    4: ["dark", "round", "toffee", "white chocolate drizzle"],
    5: ["milk", "square", "caramel", "nuts"],
    6: ["milk", "heart", "toffee", "dark chocolate drizzle"],
    7: ["dark", "rectangle", "caramel", "none"],
    8: ["dark", "heart", "strawberry", "white chocolate drizzle"],
    9: ["dark", "heart", "coconut", "white chocolate drizzle"],
    10: ["milk", "square", "coconut", "none"],
    11: ["milk", "round", "vanilla", "dark chocolate drizzle"],
    12: ["milk", "round", "strawberry", "nuts"],
    13: ["milk", "rectangle", "caramel", "sprinkles"],
    14: ["dark", "rectangle", "toffee", "none"],
    15: ["dark", "heart", "toffee", "none"],
    16: ["dark", "heart", "coconut", "white chocolate drizzle"],
    17: ["dark", "round", "vanilla", "none"],
    18: ["dark", "rectangle", "toffee", "dark chocolate drizzle"],
    19: ["milk", "round", "toffee", "none"],
    20: ["milk", "square", "caramel", "dark chocolate drizzle"],
    21: ["milk", "square", "vanilla", "none"],
    22: ["dark", "heart", "caramel", "sprinkles"],
    23: ["milk", "square", "caramel", "nuts"],
    24: ["milk", "round", "caramel", "dark chocolate drizzle"],
    25: ["milk", "round", "coconut", "dark chocolate drizzle"],
    26: ["dark", "round", "coconut", "dark chocolate drizzle"],
    27: ["milk", "rectangle", "strawberry", "sprinkles"],
    28: ["white", "heart", "vanilla", "none"],
    29: ["dark", "heart", "strawberry", "none"],
    30: ["dark", "rectangle", "caramel", "none"],
    31: ["white", "round", "caramel", "none"],
    32: ["milk", "heart", "vanilla", "none"],
    33: ["white", "round", "strawberry", "nuts"],
    34: ["milk", "round", "coconut", "none"],
    35: ["dark", "rectangle", "coconut", "dark chocolate drizzle"],
    36: ["milk", "round", "vanilla", "dark chocolate drizzle"],
    37: ["dark", "round", "coconut", "white chocolate drizzle"],
    38: ["dark", "round", "coconut", "white chocolate drizzle"],
    39: ["dark", "round", "coconut", "dark chocolate drizzle"],
    40: ["dark", "round", "strawberry", "dark chocolate drizzle"],
    41: ["milk", "rectangle", "toffee", "none"],
    42: ["milk", "round", "strawberry", "white chocolate drizzle"],
    43: ["milk", "heart", "coconut", "none"],
    44: ["white", "round", "strawberry", "white chocolate drizzle"],
    45: ["milk", "heart", "toffee", "sprinkles"],
    46: ["milk", "rectangle", "strawberry", "none"],
    47: ["white", "round", "caramel", "dark chocolate drizzle"],
    48: ["white", "square", "toffee", "none"],
    49: ["milk", "rectangle", "toffee", "none"],
    50: ["dark", "rectangle", "caramel", "none"],
    51: ["milk", "square", "vanilla", "none"],
    52: ["dark", "round", "toffee", "dark chocolate drizzle"],
    53: ["milk", "round", "toffee", "white chocolate drizzle"],
    54: ["dark", "square", "strawberry", "none"],
    55: ["milk", "heart", "caramel", "dark chocolate drizzle"],
    56: ["milk", "heart", "vanilla", "none"],
    57: ["milk", "heart", "caramel", "none"],
    58: ["milk", "heart", "coconut", "sprinkles"],
    59: ["milk", "heart", "vanilla", "sprinkles"],
    60: ["dark", "square", "caramel", "none"],
    61: ["milk", "rectangle", "vanilla", "none"],
    62: ["milk", "heart", "toffee", "none"],
    63: ["milk", "heart", "vanilla", "dark chocolate drizzle"],
    64: ["white", "round", "coconut", "white chocolate drizzle"],
    65: ["milk", "round", "coconut", "nuts"],
    66: ["milk", "round", "coconut", "white chocolate drizzle"],
    67: ["dark", "heart", "coconut", "none"],
    68: ["dark", "square", "toffee", "none"],
    69: ["dark", "round", "strawberry", "dark chocolate drizzle"],
    70: ["milk", "heart", "caramel", "none"],
    71: ["milk", "square", "caramel", "sprinkles"],
    72: ["milk", "rectangle", "strawberry", "sprinkles"],
    73: ["dark", "heart", "strawberry", "none"],
    74: ["dark", "heart", "strawberry", "none"],
    75: ["dark", "square", "coconut", "none"],
    76: ["dark", "heart", "caramel", "none"],
    77: ["dark", "heart", "coconut", "nuts"],
    78: ["white", "rectangle", "caramel", "dark chocolate drizzle"],
    79: ["milk", "heart", "vanilla", "sprinkles"],
    80: ["white", "heart", "strawberry", "none"],
    81: ["dark", "round", "toffee", "white chocolate drizzle"],
    82: ["dark", "round", "vanilla", "none"],
    83: ["white", "square", "coconut", "none"],
    84: ["milk", "rectangle", "caramel", "dark chocolate drizzle"],
    85: ["white", "heart", "toffee", "none"],
    86: ["white", "round", "caramel", "nuts"],
    87: ["white", "round", "caramel", "none"],
    88: ["dark", "round", "caramel", "none"],
    89: ["dark", "square", "coconut", "nuts"],
    90: ["milk", "heart", "vanilla", "none"],
    91: ["dark", "round", "coconut", "none"],
    92: ["dark", "round", "caramel", "none"],
    93: ["white", "round", "toffee", "none"],
    94: ["milk", "round", "vanilla", "sprinkles"],
    95: ["white", "round", "strawberry", "white chocolate drizzle"],
    96: ["dark", "square", "strawberry", "nuts"],
    97: ["milk", "round", "vanilla", "none"],
    98: ["milk", "rectangle", "caramel", "sprinkles"],
    99: ["milk", "heart", "vanilla", "none"],
    100: ["dark", "rectangle", "strawberry", "white chocolate drizzle"]}

    result = make_boxes(chocolates)

    if result:
        print(f"Successfully created {len(result)} boxes!")
        for i, box in enumerate(result, 1):
            print(f"Box {i}: {box}")
    else:
        print("Could not find a valid solution")